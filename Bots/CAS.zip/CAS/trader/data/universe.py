"""Universe builder — constructs the list of tradeable symbols.

Broker-neutral: works with any :class:`trader.brokers.base.BrokerClient`.
For brokers that expose a bulk asset listing (Alpaca) the volume filter is
applied automatically; for brokers that don't (IBKR) the configured
``universe.stocks`` list is used as the seed.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

from trader.brokers.base import BrokerClient
from trader.brokers.types import TimeFrame
from trader.config import Config

logger = logging.getLogger(__name__)

# Sentinel that, when present in ``universe.crypto``, triggers auto-discovery of
# every tradable crypto pair from the broker (case-insensitive).
CRYPTO_ALL_SENTINEL = "ALL/ALL"

# USD-pegged stablecoins are dollar-for-dollar and produce no meaningful price
# signal; trading them wastes cash and is frequently rejected by the broker.
# Base assets matched here (before the ``/QUOTE`` suffix) are excluded from the
# auto-discovered crypto universe.
STABLECOIN_BASES = frozenset(
    {"USDC", "USDT", "USDG", "DAI", "USDP", "PYUSD", "BUSD", "GUSD", "TUSD", "USD"}
)


def build_universe(broker: BrokerClient, cfg: Config) -> list[str]:
    """Return a list of symbols that meet volume and tradability filters."""
    symbols: list[str] = []

    # 1. Seed with configured explicit stocks (always honoured).
    seed = list(cfg.universe.stocks)

    # 2. If the broker supports bulk listing, discover + volume-filter.
    discovered: list[str] = []
    tradable = broker.list_tradable_equities()
    if tradable:
        all_stocks = [i.symbol for i in tradable]
        logger.info("Broker reports %d tradeable equities", len(all_stocks))
        # Allow optional pre-filtering to avoid building bars for an enormous
        # discovered list on constrained hardware (Raspberry Pi, etc.). This
        # limits how many symbols we send to the (expensive) volume filter.
        max_disc = getattr(cfg.universe, "max_discovered", 0) or 0
        if max_disc > 0 and len(all_stocks) > max_disc:
            logger.info(
                "Pre-filtering discovered equities: trimming %d -> %d per cfg.universe.max_discovered",
                len(all_stocks),
                max_disc,
            )
            all_stocks = all_stocks[:max_disc]
        discovered = _volume_filter(broker, all_stocks, cfg)
    elif seed:
        logger.info("Broker has no bulk listing; using %d configured stocks", len(seed))
        discovered = _volume_filter(broker, seed, cfg) if cfg.universe.min_avg_volume else seed
    else:
        logger.warning(
            "No tradable equities from broker and no universe.stocks configured; "
            "universe will contain only ETFs/crypto"
        )

    for s in seed + discovered:
        if s not in symbols:
            symbols.append(s)

    # 3. Always include configured ETFs.
    for etf in cfg.universe.etfs:
        if etf not in symbols:
            symbols.append(etf)

    # 4. Add crypto pairs (only if broker supports crypto).
    if broker.capabilities.supports_crypto:
        crypto_symbols = _resolve_crypto(broker, cfg)
        for pair in crypto_symbols:
            if pair not in symbols:
                symbols.append(pair)

    logger.info("Final universe: %d symbols", len(symbols))
    return symbols


def _resolve_crypto(broker: BrokerClient, cfg: Config) -> list[str]:
    """Resolve the configured crypto list into concrete tradable pairs.

    If the configured list contains the :data:`CRYPTO_ALL_SENTINEL` (``ALL/ALL``,
    case-insensitive), every tradable crypto pair is discovered from the broker,
    restricted to those quoted in ``cfg.universe.crypto_quote`` and optionally
    volume-filtered. Otherwise the explicit list is returned unchanged.
    """
    configured = list(cfg.universe.crypto)
    use_all = any(str(p).strip().upper() == CRYPTO_ALL_SENTINEL for p in configured)
    if not use_all:
        return configured

    discovered = broker.list_tradable_crypto()
    if not discovered:
        logger.warning("ALL/ALL crypto requested but broker returned no crypto assets")
        return []

    quote = (cfg.universe.crypto_quote or "USD").upper()
    suffix = f"/{quote}"
    symbols = [
        i.symbol for i in discovered
        if i.tradable and i.symbol.upper().endswith(suffix)
    ]
    logger.info(
        "Discovered %d tradable crypto pair(s); %d quoted in %s",
        len(discovered),
        len(symbols),
        quote,
    )

    # Drop USD-pegged stablecoins (e.g. USDC/USD) — no signal, wastes cash,
    # and the broker routinely rejects them.
    before = len(symbols)
    symbols = [
        s for s in symbols
        if s.upper().split("/", 1)[0] not in STABLECOIN_BASES
    ]
    if before != len(symbols):
        logger.info(
            "Excluded %d stablecoin pair(s) from crypto universe", before - len(symbols)
        )

    if cfg.universe.min_crypto_volume > 0 and symbols:
        symbols = _crypto_volume_filter(broker, symbols, cfg)

    logger.info("Crypto universe (ALL/ALL): %d pair(s) after filters", len(symbols))
    return symbols


def _crypto_volume_filter(broker: BrokerClient, symbols: list[str], cfg: Config) -> list[str]:
    """Keep crypto pairs whose recent average daily volume clears the threshold."""
    if not broker.capabilities.supports_bar_history:
        return list(symbols)

    end = datetime.now()
    start = end - timedelta(days=30)
    min_vol = cfg.universe.min_crypto_volume
    passed: list[str] = []

    chunk_size = 200
    for i in range(0, len(symbols), chunk_size):
        chunk = symbols[i : i + chunk_size]
        try:
            bars_by_symbol = broker.get_bars(chunk, TimeFrame.DAY, start=start, end=end)
        except Exception:
            logger.warning("Crypto volume filter failed for chunk at %d, skipping", i)
            continue
        for sym, bars in bars_by_symbol.items():
            if not bars:
                continue
            avg_vol = sum(b.volume for b in bars) / len(bars)
            if avg_vol >= min_vol:
                passed.append(sym)

    logger.info("%d crypto pair(s) passed volume filter (>=%d avg daily)", len(passed), min_vol)
    return passed


def _volume_filter(broker: BrokerClient, stocks: list[str], cfg: Config) -> list[str]:
    """Keep symbols whose 20-day average volume clears the threshold."""
    if not broker.capabilities.supports_bar_history:
        return list(stocks)

    end = datetime.now()
    start = end - timedelta(days=30)
    min_vol = cfg.universe.min_avg_volume
    passed: list[str] = []

    chunk_size = 200
    for i in range(0, len(stocks), chunk_size):
        chunk = stocks[i : i + chunk_size]
        try:
            bars_by_symbol = broker.get_bars(chunk, TimeFrame.DAY, start=start, end=end)
        except Exception:
            logger.warning("Volume filter failed for chunk at %d, skipping", i)
            continue
        for sym, bars in bars_by_symbol.items():
            if not bars:
                continue
            avg_vol = sum(b.volume for b in bars) / len(bars)
            if avg_vol >= min_vol:
                passed.append(sym)

    logger.info("%d stocks passed volume filter (>=%d avg daily)", len(passed), min_vol)
    return passed


def split_universe(symbols: list[str]) -> tuple[list[str], list[str]]:
    """Split a universe list into (stocks_and_etfs, crypto) based on '/' in symbol."""
    stocks = [s for s in symbols if "/" not in s]
    crypto = [s for s in symbols if "/" in s]
    return stocks, crypto
