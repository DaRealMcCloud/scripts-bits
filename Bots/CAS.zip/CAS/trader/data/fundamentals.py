"""Fundamental quality data from yfinance — used as a pre-filter for momentum."""

from __future__ import annotations

import logging
from dataclasses import dataclass

import yfinance as yf

from trader.config import MomentumConfig

logger = logging.getLogger(__name__)


@dataclass
class QualityMetrics:
    symbol: str
    roe: float | None = None
    debt_equity: float | None = None
    gross_margin: float | None = None
    passes: bool = False


def fetch_quality(symbol: str) -> QualityMetrics:
    """Fetch fundamental quality metrics for a single equity symbol."""
    m = QualityMetrics(symbol=symbol)
    try:
        info = yf.Ticker(symbol).info
        m.roe = info.get("returnOnEquity")
        m.debt_equity = info.get("debtToEquity")
        if m.debt_equity is not None:
            m.debt_equity = m.debt_equity / 100.0  # yfinance returns as percentage
        m.gross_margin = info.get("grossMargins")
    except Exception:
        logger.warning("Could not fetch fundamentals for %s", symbol)
    return m


def passes_quality_filter(m: QualityMetrics, cfg: MomentumConfig) -> bool:
    """Check if metrics meet minimum quality thresholds."""
    if m.roe is not None and m.roe < cfg.min_roe:
        return False
    if m.debt_equity is not None and m.debt_equity > cfg.max_debt_equity:
        return False
    if m.gross_margin is not None and m.gross_margin < cfg.min_gross_margin:
        return False
    return True


def filter_by_quality(
    symbols: list[str], cfg: MomentumConfig
) -> list[str]:
    """Return symbols that pass the fundamental quality filter."""
    passed: list[str] = []
    for sym in symbols:
        metrics = fetch_quality(sym)
        if passes_quality_filter(metrics, cfg):
            passed.append(sym)
        else:
            logger.debug(
                "Quality filter rejected %s (ROE=%.2f, D/E=%.2f, GM=%.2f)",
                sym,
                metrics.roe or 0,
                metrics.debt_equity or 0,
                metrics.gross_margin or 0,
            )
    logger.info("Quality filter: %d/%d passed", len(passed), len(symbols))
    return passed
